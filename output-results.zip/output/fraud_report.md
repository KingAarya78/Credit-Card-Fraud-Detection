
# CREDIT CARD FRAUD DETECTION REPORT

## Performance Summary
- Optimal Threshold: 0.408
- Business Cost: $5,570
- Fraud Detection Rate: 89.8%
- False Positive Rate: 0.0%

## Key Metrics
              precision    recall  f1-score   support

     Genuine       1.00      1.00      1.00     56864
       Fraud       0.61      0.90      0.72        98

    accuracy                           1.00     56962
   macro avg       0.80      0.95      0.86     56962
weighted avg       1.00      1.00      1.00     56962


## System Info
- Execution Time: 0.6 minutes
- Samples Processed: 284,807
- Features Used: 31

Generated on 2025-05-09 22:32
